package com.example.monitor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemMonitorApplication {
    public static void main(String[] args) {
        SpringApplication.run(SystemMonitorApplication.class, args);
    }
}
